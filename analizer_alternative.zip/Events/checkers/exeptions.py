class TimeLogError(Exception):
    """
    Исключение при не правильном значении времени в логах
    """
