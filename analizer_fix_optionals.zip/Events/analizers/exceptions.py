class FunctionNotProvideError(Exception):
    """
    Исключение не поддерживамой функции.
    """

    pass
